package net.mikexxx.flowerbeds.client.renderer;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.BiomeColors;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.block.BlockRenderDispatcher;
import net.minecraft.client.renderer.block.model.BakedQuad;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderer;
import net.minecraft.client.renderer.blockentity.BlockEntityRendererProvider;
import net.minecraft.client.renderer.texture.TextureAtlas;
import net.minecraft.client.renderer.texture.TextureAtlasSprite;
import net.minecraft.client.resources.model.BakedModel;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.util.RandomSource;
import net.minecraft.world.inventory.InventoryMenu;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.AzaleaBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.LeavesBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.RenderTypeHelper;
import net.minecraftforge.client.model.data.ModelData;

import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Draws the items of a bed at their real size. Scaled fruit is drawn smaller and turned. A dense plant texture
 * is drawn as one covering plane so neighbouring crosses do not flicker. Pot fill is a solid, textured volume
 * up to just under the rim, and water (including dyed water) is the same kind of volume with plants stood on it.
 */
public class PlantBedRenderer<T extends PlantBedBlockEntity> implements BlockEntityRenderer<T> {

    private static final RandomSource RANDOM = RandomSource.create(42L);
    private static final Map<BlockState, ModelInfo> MODELS = new HashMap<>();

    public PlantBedRenderer(BlockEntityRendererProvider.Context context) {
    }

    @Override
    public boolean shouldRender(T bed, Vec3 camera) {
        if (bed.baseState() == null && bed.substrateState() == null && !bed.hasContents()) {
            if (!(bed instanceof LargePotBlockEntity pot) || pot.getLiquid() == LargePotBlock.Liquid.NONE) {
                return false;
            }
        }
        return BlockEntityRenderer.super.shouldRender(bed, camera);
    }

    @Override
    public void render(T bed, float partialTick, PoseStack poseStack, MultiBufferSource buffers,
                       int packedLight, int packedOverlay) {
        Level level = bed.getLevel();
        if (level == null) {
            return;
        }
        BlockPos pos = bed.getBlockPos();
        float baseY = bed.bedHeight();

        BlockState base = bed.baseState();
        if (base != null) {
            renderBaseBlock(base, level, pos, poseStack, buffers, packedOverlay);
        }

        boolean pot = bed instanceof LargePotBlockEntity;
        if (pot) {
            LargePotBlockEntity potBed = (LargePotBlockEntity) bed;
            BlockState substrate = potBed.substrateState();
            if (substrate != null) {
                renderPotSubstrate(substrate, potBed, level, pos, poseStack, buffers, packedOverlay);
            }
            if (potBed.getLiquid() != LargePotBlock.Liquid.NONE) {
                renderPotLiquid(potBed, level, pos, poseStack, buffers, packedOverlay);
            }
        }

        int light = LevelRenderer.getLightColor(level, baseY >= 1.0F ? pos.above() : pos);
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            ItemStack stack = bed.getSlot(i);
            if (stack.isEmpty()) {
                continue;
            }
            List<BlockState> column = PlantStates.columnFor(stack, bed.getAge(i));
            if (column.isEmpty()) {
                continue;
            }
            if (pot && ((LargePotBlockEntity) bed).getLiquid() == LargePotBlock.Liquid.WATER) {
                column = liftedOutOfWater(column);
            }
            float x = pot && i < GardenLayout.POT_PLANT_SLOTS ? GardenLayout.potLocalX(i) : GardenLayout.localX(i);
            float z = pot && i < GardenLayout.POT_PLANT_SLOTS ? GardenLayout.potLocalZ(i) : GardenLayout.localZ(i);
            boolean scaled = GardenLayout.isScaled(stack);
            float aquatic = pot && PlantStates.isAquatic(column.get(0))
                    && ((LargePotBlockEntity) bed).getLiquid() == LargePotBlock.Liquid.WATER ? 0.02F : 0.0F;
            for (int k = 0; k < column.size(); k++) {
                poseStack.pushPose();
                if (scaled) {
                    poseStack.translate(x, baseY + aquatic, z);
                    poseStack.mulPose(Axis.YP.rotationDegrees(bed.getRotation(i) * 90.0F));
                    float s = GardenLayout.SCALED_FRUIT_SCALE;
                    poseStack.scale(s, s, s);
                    poseStack.translate(-0.5, 0.0, -0.5);
                } else {
                    poseStack.translate(x - 0.5, baseY + k + aquatic, z - 0.5);
                }
                int blockLight = LevelRenderer.getLightColor(level, pos.above(k + (baseY >= 1.0F ? 1 : 0)));
                renderState(column.get(k), level, pos, poseStack, buffers, blockLight, packedOverlay, i);
                poseStack.popPose();
            }
        }

        ItemStack groundcover = bed.getSlot(GardenLayout.GROUNDCOVER_SLOT);
        if (!groundcover.isEmpty()) {
            poseStack.pushPose();
            poseStack.translate(0.0, baseY + 0.004, 0.0);
            BlockState state = PlantStates.stateFor(groundcover, bed.getAge(GardenLayout.GROUNDCOVER_SLOT));
            if (pot && ((LargePotBlockEntity) bed).getLiquid() == LargePotBlock.Liquid.WATER) {
                state = clearWaterlogged(state);
            }
            renderState(state, level, pos, poseStack, buffers, light, packedOverlay, 0);
            poseStack.popPose();
        }
    }

    /** Aquatic plants are drawn as their above-water state so the water volume does not swallow them. */
    private static List<BlockState> liftedOutOfWater(List<BlockState> column) {
        if (!PlantStates.isAquatic(column.get(0))) {
            return column;
        }
        List<BlockState> lifted = new ArrayList<>(column.size());
        for (BlockState state : column) {
            lifted.add(clearWaterlogged(state));
        }
        return lifted;
    }

    private static BlockState clearWaterlogged(BlockState state) {
        if (state.hasProperty(BlockStateProperties.WATERLOGGED)) {
            return state.setValue(BlockStateProperties.WATERLOGGED, false);
        }
        return state;
    }

    private void renderState(BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay, int slot) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        if (state.getRenderShape() != RenderShape.MODEL) {
            dispatcher.renderSingleBlock(state, poseStack, buffers, light, overlay);
            return;
        }
        ModelInfo info = info(state);
        // A dense texture flickering against its neighbours is replaced by one plane of that same texture.
        // A tall, detailed model is left alone so modern plants keep their shape, and is only nudged apart.
        if (info.dense && info.sprite != null && !(info.maxY > 2.5F && info.quads > 12)) {
            renderCover(info, state, level, tintPos, poseStack, buffers, light, overlay, slot);
            return;
        }
        poseStack.pushPose();
        poseStack.translate((slot & 3) * 0.0016F, slot * 0.0012F, ((slot >> 2) & 3) * 0.0016F);
        int rgb = PlantTint.color(state, level, tintPos, 0);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        BakedModel model = dispatcher.getBlockModel(state);
        for (RenderType renderType : info.types) {
            dispatcher.getModelRenderer().renderModel(poseStack.last(),
                    buffers.getBuffer(RenderTypeHelper.getEntityRenderType(renderType, false)),
                    state, model, r, g, b, light, overlay, ModelData.EMPTY, renderType);
        }
        poseStack.popPose();
    }

    /** One double-sided plane of the plant texture. It cannot z-fight with itself, and each slot is turned. */
    private void renderCover(ModelInfo info, BlockState state, Level level, BlockPos tintPos, PoseStack poseStack,
                             MultiBufferSource buffers, int light, int overlay, int slot) {
        int rgb = PlantTint.color(state, level, tintPos, info.tint);
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float height = Math.max(1.0F, info.maxY);
        TextureAtlasSprite sprite = info.sprite;
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
        poseStack.pushPose();
        poseStack.translate(0.5, 0.0, 0.5);
        poseStack.mulPose(Axis.YP.rotationDegrees(45.0F + slot * 13.0F));
        poseStack.translate(-0.5, 0.0, -0.5);
        PoseStack.Pose pose = poseStack.last();
        float x0 = 0.08F;
        float x1 = 0.92F;
        float z = 0.5F;
        float u0 = sprite.getU0();
        float u1 = sprite.getU1();
        float v0 = sprite.getV0();
        float v1 = sprite.getV1();
        // Front: top-left, top-right, bottom-right, bottom-left.
        vertex(consumer, pose, x0, height, z, r, g, b, 1, u0, v0, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x1, height, z, r, g, b, 1, u1, v0, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x1, 0, z, r, g, b, 1, u1, v1, overlay, light, 0, 0, 1);
        vertex(consumer, pose, x0, 0, z, r, g, b, 1, u0, v1, overlay, light, 0, 0, 1);
        // Back, opposite winding, same texture.
        vertex(consumer, pose, x1, height, z, r, g, b, 1, u1, v0, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x0, height, z, r, g, b, 1, u0, v0, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x0, 0, z, r, g, b, 1, u0, v1, overlay, light, 0, 0, -1);
        vertex(consumer, pose, x1, 0, z, r, g, b, 1, u1, v1, overlay, light, 0, 0, -1);
        poseStack.popPose();
    }

    private void renderPotSubstrate(BlockState substrate, LargePotBlockEntity pot, Level level, BlockPos pos,
                                    PoseStack poseStack, MultiBufferSource buffers, int overlay) {
        BlockState potState = pot.getBlockState();
        if (!(potState.getBlock() instanceof LargePotBlock)) {
            return;
        }
        float x0 = potState.getValue(LargePotBlock.WEST) ? 0.001F : 2.0F / 16.0F;
        float x1 = potState.getValue(LargePotBlock.EAST) ? 0.999F : 14.0F / 16.0F;
        float z0 = potState.getValue(LargePotBlock.NORTH) ? 0.001F : 2.0F / 16.0F;
        float z1 = potState.getValue(LargePotBlock.SOUTH) ? 0.999F : 14.0F / 16.0F;
        float y0 = GardenLayout.POT_FILL_BOTTOM;
        float y1 = GardenLayout.POT_FILL_TOP;
        int light = LevelRenderer.getLightColor(level, pos.above());
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
        PoseStack.Pose pose = poseStack.last();
        Face top = face(substrate, Direction.UP);
        Face down = face(substrate, Direction.DOWN);
        horizontal(consumer, pose, x0, y1, z0, x1, y1, z1, top, substrate, level, pos, overlay, light, true);
        horizontal(consumer, pose, x0, y0, z0, x1, y0, z1, down, substrate, level, pos, overlay, light, false);
        if (!potState.getValue(LargePotBlock.NORTH) || !neighborSubstrate(level, pos.north())) {
            sideZ(consumer, pose, x0, x1, y0, y1, z0, face(substrate, Direction.NORTH), substrate, level, pos, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.SOUTH) || !neighborSubstrate(level, pos.south())) {
            sideZ(consumer, pose, x0, x1, y0, y1, z1, face(substrate, Direction.SOUTH), substrate, level, pos, overlay, light, true);
        }
        if (!potState.getValue(LargePotBlock.WEST) || !neighborSubstrate(level, pos.west())) {
            sideX(consumer, pose, z0, z1, y0, y1, x0, face(substrate, Direction.WEST), substrate, level, pos, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.EAST) || !neighborSubstrate(level, pos.east())) {
            sideX(consumer, pose, z0, z1, y0, y1, x1, face(substrate, Direction.EAST), substrate, level, pos, overlay, light, true);
        }
    }

    private void renderPotLiquid(LargePotBlockEntity pot, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, int overlay) {
        BlockState potState = pot.getBlockState();
        if (!(potState.getBlock() instanceof LargePotBlock)) {
            return;
        }
        LargePotBlock.Liquid liquid = pot.getLiquid();
        boolean lava = liquid == LargePotBlock.Liquid.LAVA;
        TextureAtlasSprite sprite = Minecraft.getInstance().getTextureAtlas(InventoryMenu.BLOCK_ATLAS)
                .apply(new net.minecraft.resources.ResourceLocation("minecraft", lava ? "block/lava_still" : "block/water_still"));
        int rgb = 0xFFFFFF;
        if (liquid == LargePotBlock.Liquid.WATER) {
            rgb = pot.getDyeColor() >= 0 ? pot.getDyeColor() : BiomeColors.getAverageWaterColor(level, pos);
        }
        float r = (rgb >> 16 & 255) / 255.0F;
        float g = (rgb >> 8 & 255) / 255.0F;
        float b = (rgb & 255) / 255.0F;
        float alpha = lava ? 1.0F : 0.85F;
        int light = lava ? LightTexture.FULL_BRIGHT : LevelRenderer.getLightColor(level, pos.above());
        float x0 = potState.getValue(LargePotBlock.WEST) ? 0.001F : 2.0F / 16.0F;
        float x1 = potState.getValue(LargePotBlock.EAST) ? 0.999F : 14.0F / 16.0F;
        float z0 = potState.getValue(LargePotBlock.NORTH) ? 0.001F : 2.0F / 16.0F;
        float z1 = potState.getValue(LargePotBlock.SOUTH) ? 0.999F : 14.0F / 16.0F;
        float y0 = GardenLayout.POT_FILL_BOTTOM;
        float y1 = GardenLayout.POT_WATER_TOP;
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityTranslucent(TextureAtlas.LOCATION_BLOCKS));
        PoseStack.Pose pose = poseStack.last();
        Face face = new Face(sprite, -1);
        tintedHorizontal(consumer, pose, x0, y1, z0, x1, y1, z1, face, r, g, b, alpha, overlay, light, true);
        tintedHorizontal(consumer, pose, x0, y0, z0, x1, y0, z1, face, r * 0.7F, g * 0.7F, b * 0.7F, alpha, overlay, light, false);
        float sr = r * 0.8F;
        float sg = g * 0.8F;
        float sb = b * 0.8F;
        if (!potState.getValue(LargePotBlock.NORTH) || !neighborLiquid(level, pos.north(), liquid)) {
            tintedSideZ(consumer, pose, x0, x1, y0, y1, z0, face, sr, sg, sb, alpha, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.SOUTH) || !neighborLiquid(level, pos.south(), liquid)) {
            tintedSideZ(consumer, pose, x0, x1, y0, y1, z1, face, sr, sg, sb, alpha, overlay, light, true);
        }
        if (!potState.getValue(LargePotBlock.WEST) || !neighborLiquid(level, pos.west(), liquid)) {
            tintedSideX(consumer, pose, z0, z1, y0, y1, x0, face, sr, sg, sb, alpha, overlay, light, false);
        }
        if (!potState.getValue(LargePotBlock.EAST) || !neighborLiquid(level, pos.east(), liquid)) {
            tintedSideX(consumer, pose, z0, z1, y0, y1, x1, face, sr, sg, sb, alpha, overlay, light, true);
        }
    }

    private static boolean neighborSubstrate(Level level, BlockPos pos) {
        return level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.getSubstrate() != null;
    }

    private static boolean neighborLiquid(Level level, BlockPos pos, LargePotBlock.Liquid liquid) {
        return level.getBlockEntity(pos) instanceof LargePotBlockEntity pot && pot.getLiquid() == liquid;
    }

    private void renderBaseBlock(BlockState base, Level level, BlockPos pos, PoseStack poseStack,
                                 MultiBufferSource buffers, int overlay) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(base);
        VertexConsumer consumer = buffers.getBuffer(RenderType.entityCutoutNoCull(TextureAtlas.LOCATION_BLOCKS));
        boolean full = false;
        try {
            full = base.isCollisionShapeFullBlock(level, pos);
        } catch (RuntimeException ignored) {
            full = false;
        }
        for (Direction face : Direction.values()) {
            if (full) {
                BlockPos neighbor = pos.relative(face);
                if (!Block.shouldRenderFace(base, level, pos, face, neighbor)) {
                    continue;
                }
            }
            int light = LevelRenderer.getLightColor(level, full ? pos.relative(face) : pos);
            float shade = level.getShade(face, true);
            for (BakedQuad quad : model.getQuads(base, face, RANDOM, ModelData.EMPTY, null)) {
                putQuad(consumer, poseStack, quad, base, level, pos, shade, light, overlay);
            }
        }
        int light = LevelRenderer.getLightColor(level, pos);
        for (BakedQuad quad : model.getQuads(base, null, RANDOM, ModelData.EMPTY, null)) {
            putQuad(consumer, poseStack, quad, base, level, pos, 1.0F, light, overlay);
        }
    }

    private static void putQuad(VertexConsumer consumer, PoseStack poseStack, BakedQuad quad, BlockState base,
                                Level level, BlockPos pos, float shade, int light, int overlay) {
        int rgb = PlantTint.color(base, level, pos, quad.getTintIndex());
        float s = quad.isShade() ? shade : 1.0F;
        consumer.putBulkData(poseStack.last(), quad,
                s * (rgb >> 16 & 255) / 255.0F, s * (rgb >> 8 & 255) / 255.0F, s * (rgb & 255) / 255.0F,
                light, overlay);
    }

    private ModelInfo info(BlockState state) {
        ModelInfo cached = MODELS.get(state);
        if (cached != null) {
            return cached;
        }
        ModelInfo baked;
        try {
            baked = bake(state);
        } catch (RuntimeException e) {
            baked = ModelInfo.fallback();
        }
        MODELS.put(state, baked);
        return baked;
    }

    private ModelInfo bake(BlockState state) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(state);
        float minX = 0, minY = 0, minZ = 0, maxX = 1, maxY = 1, maxZ = 1;
        boolean any = false;
        int quads = 0;
        int tint = -1;
        TextureAtlasSprite sprite = model.getParticleIcon(ModelData.EMPTY);
        for (Direction face : iterateFaces()) {
            for (BakedQuad quad : model.getQuads(state, face, RANDOM, ModelData.EMPTY, null)) {
                quads++;
                if (sprite == null || face == Direction.UP) {
                    sprite = quad.getSprite();
                }
                if (tint < 0) {
                    tint = quad.getTintIndex();
                }
                int[] v = quad.getVertices();
                int stride = v.length / 4;
                for (int i = 0; i < 4; i++) {
                    float x = Float.intBitsToFloat(v[i * stride]);
                    float y = Float.intBitsToFloat(v[i * stride + 1]);
                    float z = Float.intBitsToFloat(v[i * stride + 2]);
                    if (!any) {
                        minX = maxX = x;
                        minY = maxY = y;
                        minZ = maxZ = z;
                        any = true;
                    } else {
                        minX = Math.min(minX, x);
                        minY = Math.min(minY, y);
                        minZ = Math.min(minZ, z);
                        maxX = Math.max(maxX, x);
                        maxY = Math.max(maxY, y);
                        maxZ = Math.max(maxZ, z);
                    }
                }
            }
        }
        if (!any) {
            minX = minY = minZ = 0;
            maxX = maxY = maxZ = 1;
        }
        float opacity = sprite == null ? 0 : opacity(sprite);
        boolean leafy = state.getBlock() instanceof LeavesBlock || state.getBlock() instanceof AzaleaBlock;
        boolean dense = leafy || opacity >= 0.50F;
        List<RenderType> types = model.getRenderTypes(state, RANDOM, ModelData.EMPTY).asList();
        return new ModelInfo(minX, minY, minZ, maxX, maxY, maxZ, quads, dense, tint, sprite, types);
    }

    private static Direction[] iterateFaces() {
        return new Direction[] {Direction.DOWN, Direction.UP, Direction.NORTH, Direction.SOUTH, Direction.WEST, Direction.EAST, null};
    }

    private static float opacity(TextureAtlasSprite sprite) {
        try {
            Object contents = sprite.contents();
            com.mojang.blaze3d.platform.NativeImage image = null;
            Class<?> type = contents.getClass();
            while (type != null && image == null) {
                for (Field field : type.getDeclaredFields()) {
                    field.setAccessible(true);
                    Object value = field.get(contents);
                    if (value instanceof com.mojang.blaze3d.platform.NativeImage nativeImage) {
                        image = nativeImage;
                        break;
                    }
                    if (value instanceof com.mojang.blaze3d.platform.NativeImage[] images && images.length > 0 && images[0] != null) {
                        image = images[0];
                        break;
                    }
                }
                type = type.getSuperclass();
            }
            if (image == null) {
                return 0;
            }
            int w = image.getWidth();
            int h = image.getHeight();
            int stepX = Math.max(1, w / 16);
            int stepY = Math.max(1, h / 16);
            int total = 0;
            int opaque = 0;
            for (int y = 0; y < h; y += stepY) {
                for (int x = 0; x < w; x += stepX) {
                    total++;
                    int pixel = image.getPixelRGBA(x, y);
                    if (((pixel >>> 24) & 255) > 200) {
                        opaque++;
                    }
                }
            }
            return total == 0 ? 0 : opaque / (float) total;
        } catch (Throwable ignored) {
            return 0;
        }
    }

    private Face face(BlockState state, Direction direction) {
        BlockRenderDispatcher dispatcher = Minecraft.getInstance().getBlockRenderer();
        BakedModel model = dispatcher.getBlockModel(state);
        List<BakedQuad> quads = model.getQuads(state, direction, RANDOM, ModelData.EMPTY, null);
        if (quads.isEmpty()) {
            quads = model.getQuads(state, null, RANDOM, ModelData.EMPTY, null);
        }
        if (quads.isEmpty()) {
            return new Face(model.getParticleIcon(ModelData.EMPTY), -1);
        }
        return new Face(quads.get(0).getSprite(), quads.get(0).getTintIndex());
    }

    private void horizontal(VertexConsumer consumer, PoseStack.Pose pose, float x0, float y, float z0,
                            float x1, float y2, float z1, Face face, BlockState state, Level level, BlockPos pos,
                            int overlay, int light, boolean up) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = up ? 1.0F : 0.5F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedHorizontal(consumer, pose, x0, y, z0, x1, y2, z1, face, r, g, b, 1, overlay, light, up);
    }

    private void tintedHorizontal(VertexConsumer consumer, PoseStack.Pose pose, float x0, float y, float z0,
                                  float x1, float ignoredY, float z1, Face face, float r, float g, float b, float a,
                                  int overlay, int light, boolean up) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV(z0 * 16.0F);
        float v1 = sprite.getV(z1 * 16.0F);
        float ny = up ? 1 : -1;
        if (up) {
            vertex(consumer, pose, x0, y, z0, r, g, b, a, u0, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x0, y, z1, r, g, b, a, u0, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z1, r, g, b, a, u1, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z0, r, g, b, a, u1, v0, overlay, light, 0, ny, 0);
        } else {
            vertex(consumer, pose, x0, y, z0, r, g, b, a, u0, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z0, r, g, b, a, u1, v0, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x1, y, z1, r, g, b, a, u1, v1, overlay, light, 0, ny, 0);
            vertex(consumer, pose, x0, y, z1, r, g, b, a, u0, v1, overlay, light, 0, ny, 0);
        }
    }

    private void sideZ(VertexConsumer consumer, PoseStack.Pose pose, float x0, float x1, float y0, float y1, float z,
                       Face face, BlockState state, Level level, BlockPos pos, int overlay, int light, boolean positive) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = 0.8F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedSideZ(consumer, pose, x0, x1, y0, y1, z, face, r, g, b, 1, overlay, light, positive);
    }

    private void tintedSideZ(VertexConsumer consumer, PoseStack.Pose pose, float x0, float x1, float y0, float y1, float z,
                             Face face, float r, float g, float b, float a, int overlay, int light, boolean positive) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(x0 * 16.0F);
        float u1 = sprite.getU(x1 * 16.0F);
        float v0 = sprite.getV((1.0F - y1) * 16.0F);
        float v1 = sprite.getV((1.0F - y0) * 16.0F);
        float nz = positive ? 1 : -1;
        if (positive) {
            vertex(consumer, pose, x0, y1, z, r, g, b, a, u0, v0, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y0, z, r, g, b, a, u0, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y0, z, r, g, b, a, u1, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y1, z, r, g, b, a, u1, v0, overlay, light, 0, 0, nz);
        } else {
            vertex(consumer, pose, x1, y1, z, r, g, b, a, u1, v0, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x1, y0, z, r, g, b, a, u1, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y0, z, r, g, b, a, u0, v1, overlay, light, 0, 0, nz);
            vertex(consumer, pose, x0, y1, z, r, g, b, a, u0, v0, overlay, light, 0, 0, nz);
        }
    }

    private void sideX(VertexConsumer consumer, PoseStack.Pose pose, float z0, float z1, float y0, float y1, float x,
                       Face face, BlockState state, Level level, BlockPos pos, int overlay, int light, boolean positive) {
        int rgb = PlantTint.color(state, level, pos, face.tint);
        float shade = 0.6F;
        float r = shade * (rgb >> 16 & 255) / 255.0F;
        float g = shade * (rgb >> 8 & 255) / 255.0F;
        float b = shade * (rgb & 255) / 255.0F;
        tintedSideX(consumer, pose, z0, z1, y0, y1, x, face, r, g, b, 1, overlay, light, positive);
    }

    private void tintedSideX(VertexConsumer consumer, PoseStack.Pose pose, float z0, float z1, float y0, float y1, float x,
                             Face face, float r, float g, float b, float a, int overlay, int light, boolean positive) {
        TextureAtlasSprite sprite = face.sprite;
        float u0 = sprite.getU(z0 * 16.0F);
        float u1 = sprite.getU(z1 * 16.0F);
        float v0 = sprite.getV((1.0F - y1) * 16.0F);
        float v1 = sprite.getV((1.0F - y0) * 16.0F);
        float nx = positive ? 1 : -1;
        if (positive) {
            vertex(consumer, pose, x, y1, z1, r, g, b, a, u0, v0, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z1, r, g, b, a, u0, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z0, r, g, b, a, u1, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y1, z0, r, g, b, a, u1, v0, overlay, light, nx, 0, 0);
        } else {
            vertex(consumer, pose, x, y1, z0, r, g, b, a, u1, v0, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z0, r, g, b, a, u1, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y0, z1, r, g, b, a, u0, v1, overlay, light, nx, 0, 0);
            vertex(consumer, pose, x, y1, z1, r, g, b, a, u0, v0, overlay, light, nx, 0, 0);
        }
    }

    private static void vertex(VertexConsumer consumer, PoseStack.Pose pose, float x, float y, float z,
                               float r, float g, float b, float a, float u, float v, int overlay, int light,
                               float nx, float ny, float nz) {
        consumer.vertex(pose.pose(), x, y, z).color(r, g, b, a).uv(u, v).overlayCoords(overlay)
                .uv2(light).normal(pose.normal(), nx, ny, nz).endVertex();
    }

    private record Face(TextureAtlasSprite sprite, int tint) {}

    private static final class ModelInfo {
        final float minX, minY, minZ, maxX, maxY, maxZ;
        final int quads;
        final boolean dense;
        final int tint;
        final TextureAtlasSprite sprite;
        final List<RenderType> types;

        ModelInfo(float minX, float minY, float minZ, float maxX, float maxY, float maxZ, int quads, boolean dense,
                  int tint, TextureAtlasSprite sprite, List<RenderType> types) {
            this.minX = minX;
            this.minY = minY;
            this.minZ = minZ;
            this.maxX = maxX;
            this.maxY = maxY;
            this.maxZ = maxZ;
            this.quads = quads;
            this.dense = dense;
            this.tint = tint;
            this.sprite = sprite;
            this.types = types;
        }

        static ModelInfo fallback() {
            return new ModelInfo(0, 0, 0, 1, 1, 1, 0, false, -1, null, List.of());
        }
    }
}
