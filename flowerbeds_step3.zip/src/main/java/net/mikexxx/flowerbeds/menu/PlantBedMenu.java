package net.mikexxx.flowerbeds.menu;

import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.mikexxx.flowerbeds.registry.ModMenus;
import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.inventory.AbstractContainerMenu;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

/** Arrange Plants: the bed's plant slots, a groundcover slot, and the player inventory. */
public class PlantBedMenu extends AbstractContainerMenu {

    /** Slot positions, measured from the top-left of the GUI. Grid cells are 18 pixels apart. */
    private static final int GRID_ORIGIN_X = 25;
    private static final int GRID_ORIGIN_Y = 24;
    private static final int GRID_STEP = 18;
    /** Even 3x3 for a pot, lined up with the groundcover slot on the right. */
    private static final int POT_ORIGIN_X = 43;
    private static final int POT_ORIGIN_Y = 68;
    private static final int GROUNDCOVER_X = 143;
    private static final int GROUNDCOVER_Y = 86;

    private final PlantBedBlockEntity bed;

    /** Client side: the server sends the bed position, whether it is a pot, the mask and the GUI facing. */
    public PlantBedMenu(int id, Inventory inventory, FriendlyByteBuf buf) {
        this(id, inventory, buf.readBlockPos(), buf.readBoolean(), buf.readInt(), buf.readInt());
    }

    private PlantBedMenu(int id, Inventory inventory, BlockPos ignoredPos, boolean pot, int mask, int facing) {
        this(id, inventory, PlantBedStorage.forClient(mask), null, pot, facing);
    }

    /** Server side. {@code facing} is the way the player faces, which decides how a soil or bedding GUI is turned. */
    public PlantBedMenu(int id, Inventory inventory, PlantBedBlockEntity bed, int facing) {
        this(id, inventory, PlantBedStorage.forServer(bed, inventory.player), bed,
                GardenLayout.isPot(bed.getBlockState()), facing);
    }

    private PlantBedMenu(int id, Inventory inventory, PlantBedStorage storage, PlantBedBlockEntity bed,
                         boolean pot, int facing) {
        super(ModMenus.PLANT_BED.get(), id);
        this.bed = bed;

        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            int x;
            int y;
            x = GRID_ORIGIN_X + GRID_STEP * GardenLayout.guiX(i, facing);
            y = GRID_ORIGIN_Y + GRID_STEP * GardenLayout.guiZ(i, facing);
            addSlot(new GardenSlot(storage, i, x, y, storage.isActive(i)));
        }
        addSlot(new GardenSlot(storage, GardenLayout.GROUNDCOVER_SLOT, GROUNDCOVER_X, GROUNDCOVER_Y, true));

        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 9; col++) {
                addSlot(new Slot(inventory, col + row * 9 + 9, 8 + col * 18, 122 + row * 18));
            }
        }
        for (int col = 0; col < 9; col++) {
            addSlot(new Slot(inventory, col, 8 + col * 18, 180));
        }
    }

    @Override
    public boolean stillValid(Player player) {
        if (bed == null) {
            return true;
        }
        Level level = bed.getLevel();
        BlockPos pos = bed.getBlockPos();
        return level != null
                && level.getBlockEntity(pos) == bed
                && player.distanceToSqr(Vec3.atCenterOf(pos)) <= 64.0;
    }

    /**
     * Puts as much of the stack as fits into the bed slots in [from, to): first onto matching stacks that have
     * room (candles, petals), then into empty slots. Each slot takes at most its own limit for this item.
     * Returns whether anything moved.
     */
    private boolean insertInto(ItemStack stack, int from, int to) {
        boolean moved = false;
        for (int pass = 0; pass < 2 && !stack.isEmpty(); pass++) {
            for (int i = from; i < to && !stack.isEmpty(); i++) {
                Slot slot = this.slots.get(i);
                if (!slot.isActive() || !slot.mayPlace(stack)) {
                    continue;
                }
                ItemStack present = slot.getItem();
                int limit = slot.getMaxStackSize(stack);
                if (pass == 0 && !present.isEmpty() && ItemStack.isSameItemSameTags(present, stack)
                        && present.getCount() < limit) {
                    int add = Math.min(limit - present.getCount(), stack.getCount());
                    present.grow(add);
                    stack.shrink(add);
                    slot.setChanged();
                    slot.set(present);
                    moved = true;
                } else if (pass == 1 && present.isEmpty()) {
                    int add = Math.min(limit, stack.getCount());
                    slot.set(stack.copyWithCount(add));
                    stack.shrink(add);
                    moved = true;
                }
            }
        }
        return moved;
    }

    /** Shift-click moves items between the GUI and the player inventory. */
    @Override
    public ItemStack quickMoveStack(Player player, int index) {
        Slot slot = this.slots.get(index);
        if (slot == null || !slot.hasItem()) {
            return ItemStack.EMPTY;
        }
        ItemStack original = slot.getItem();
        ItemStack copy = original.copy();

        if (index < GardenLayout.SLOT_COUNT) {
            if (!this.moveItemStackTo(original, GardenLayout.SLOT_COUNT, this.slots.size(), true)) {
                return ItemStack.EMPTY;
            }
        } else {
            // Flat covers (petals, leaf litter, carpets) go to the groundcover slot first, everything else to plants.
            boolean cover = PlantStates.isGroundcover(original);
            boolean moved = cover
                    ? insertInto(original, GardenLayout.GROUNDCOVER_SLOT, GardenLayout.SLOT_COUNT)
                            | insertInto(original, 0, GardenLayout.PLANT_SLOTS)
                    : insertInto(original, 0, GardenLayout.PLANT_SLOTS)
                            | insertInto(original, GardenLayout.GROUNDCOVER_SLOT, GardenLayout.SLOT_COUNT);
            if (!moved) {
                return ItemStack.EMPTY;
            }
        }

        if (original.isEmpty()) {
            slot.set(ItemStack.EMPTY);
        } else {
            slot.setChanged();
        }
        return copy;
    }
}
