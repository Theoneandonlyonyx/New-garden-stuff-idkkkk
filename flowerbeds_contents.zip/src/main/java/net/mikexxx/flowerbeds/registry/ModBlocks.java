package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.BeddingBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, PmpMikexxx.MODID);

    /** Darker, richer soil. Mines like dirt. */
    public static final RegistryObject<SoilBlock> SOIL_BLOCK = BLOCKS.register("soil_block",
            () -> new SoilBlock(BlockBehaviour.Properties.copy(Blocks.DIRT)));

    /** What the trowel turns a dirt, sand or similar block into. It has no item; it drops the original block. */
    public static final RegistryObject<BeddingBlock> BEDDING_BLOCK = BLOCKS.register("bedding_block",
            () -> new BeddingBlock(BlockBehaviour.Properties.copy(Blocks.DIRT)));

    /** Window boxes: six woods, stone and brick. The boolean says whether the box is wooden. */
    public static final Map<String, RegistryObject<WindowBoxBlock>> WINDOW_BOXES = new LinkedHashMap<>();

    static {
        for (String wood : new String[] {"oak", "spruce", "birch", "jungle", "acacia", "dark_oak"}) {
            WINDOW_BOXES.put(wood, BLOCKS.register("window_box_" + wood, () -> new WindowBoxBlock(true)));
        }
        WINDOW_BOXES.put("stone", BLOCKS.register("window_box_stone", () -> new WindowBoxBlock(false)));
        WINDOW_BOXES.put("brick", BLOCKS.register("window_box_brick", () -> new WindowBoxBlock(false)));
    }

    /** One Large Pot per dye colour, using the terracotta-style textures. */
    public static final Map<DyeColor, RegistryObject<LargePotBlock>> LARGE_POTS = new EnumMap<>(DyeColor.class);

    static {
        for (DyeColor color : DyeColor.values()) {
            LARGE_POTS.put(color, BLOCKS.register(color.getName() + "_large_pot",
                    () -> new LargePotBlock(BlockBehaviour.Properties.copy(Blocks.TERRACOTTA))));
        }
    }
}
