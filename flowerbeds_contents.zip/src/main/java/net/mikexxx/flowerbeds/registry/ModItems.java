package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.WindowBoxBlock;
import net.mikexxx.flowerbeds.item.TrowelItem;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.DyeColor;
import net.minecraft.world.item.Item;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.Map;

public class ModItems {
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, PmpMikexxx.MODID);

    /** Opens Arrange Plants on a bed; on dirt, sand and the like it makes a bedding block. */
    public static final RegistryObject<Item> TROWEL = ITEMS.register("garden_trowel",
            () -> new TrowelItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> SOIL_BLOCK_ITEM = ITEMS.register("soil_block",
            () -> new BlockItem(ModBlocks.SOIL_BLOCK.get(), new Item.Properties()));

    public static final Map<String, RegistryObject<Item>> WINDOW_BOX_ITEMS = new LinkedHashMap<>();

    static {
        for (Map.Entry<String, RegistryObject<WindowBoxBlock>> entry : ModBlocks.WINDOW_BOXES.entrySet()) {
            WINDOW_BOX_ITEMS.put(entry.getKey(), ITEMS.register("window_box_" + entry.getKey(),
                    () -> new BlockItem(entry.getValue().get(), new Item.Properties())));
        }
    }

    public static final Map<DyeColor, RegistryObject<Item>> LARGE_POT_ITEMS = new EnumMap<>(DyeColor.class);

    static {
        for (DyeColor color : DyeColor.values()) {
            LARGE_POT_ITEMS.put(color, ITEMS.register(color.getName() + "_large_pot",
                    () -> new BlockItem(ModBlocks.LARGE_POTS.get(color).get(), new Item.Properties())));
        }
    }
}
