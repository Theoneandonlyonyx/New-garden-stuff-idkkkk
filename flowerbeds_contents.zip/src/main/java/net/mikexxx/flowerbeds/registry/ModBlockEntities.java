package net.mikexxx.flowerbeds.registry;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.entity.BeddingBlockEntity;
import net.mikexxx.flowerbeds.block.entity.LargePotBlockEntity;
import net.mikexxx.flowerbeds.block.entity.WindowBoxBlockEntity;
import net.mikexxx.flowerbeds.block.entity.SoilBlockEntity;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public class ModBlockEntities {
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, PmpMikexxx.MODID);

    public static final RegistryObject<BlockEntityType<SoilBlockEntity>> SOIL =
            BLOCK_ENTITIES.register("soil_block", () -> BlockEntityType.Builder.of(
                    SoilBlockEntity::new, ModBlocks.SOIL_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<BeddingBlockEntity>> BEDDING =
            BLOCK_ENTITIES.register("bedding_block", () -> BlockEntityType.Builder.of(
                    BeddingBlockEntity::new, ModBlocks.BEDDING_BLOCK.get()).build(null));

    public static final RegistryObject<BlockEntityType<WindowBoxBlockEntity>> WINDOW_BOX =
            BLOCK_ENTITIES.register("window_box", () -> BlockEntityType.Builder.of(
                    WindowBoxBlockEntity::new,
                    ModBlocks.WINDOW_BOXES.values().stream().map(RegistryObject::get).toArray(Block[]::new)).build(null));

    public static final RegistryObject<BlockEntityType<LargePotBlockEntity>> LARGE_POT =
            BLOCK_ENTITIES.register("large_pot", () -> BlockEntityType.Builder.of(
                    LargePotBlockEntity::new,
                    ModBlocks.LARGE_POTS.values().stream().map(RegistryObject::get).toArray(Block[]::new)
            ).build(null));
}
