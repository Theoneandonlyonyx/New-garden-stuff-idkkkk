package net.mikexxx.flowerbeds.item;

import net.mikexxx.flowerbeds.block.BeddingBlock;
import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.block.entity.BeddingBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.registry.ModBlocks;
import net.minecraft.core.BlockPos;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;

/**
 * The trowel. Beds handle it themselves (they open Arrange Plants). Used on a dirt, sand or other growing
 * block outside a pot, it turns that block into a bedding block. Sneaking on an empty bedding block turns it
 * back into the block it came from.
 */
public class TrowelItem extends Item {

    public TrowelItem(Item.Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        BlockPos pos = context.getClickedPos();
        BlockState state = level.getBlockState(pos);

        if (state.getBlock() instanceof BeddingBlock) {
            Player player = context.getPlayer();
            if (player == null || !player.isShiftKeyDown()) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide && level.getBlockEntity(pos) instanceof BeddingBlockEntity bedding) {
                BlockState original = bedding.getOriginalState();
                bedding.dropContents();
                level.setBlock(pos, original, Block.UPDATE_ALL);
                level.playSound(null, pos, original.getSoundType().getPlaceSound(),
                        SoundSource.BLOCKS, 1.0F, 1.0F);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }

        if (state.getBlock() instanceof PlantBedBlock || !GardenLayout.isSubstrateState(state, level, pos)) {
            return InteractionResult.PASS;
        }
        if (!level.isClientSide) {
            level.setBlock(pos, ModBlocks.BEDDING_BLOCK.get().defaultBlockState(), Block.UPDATE_ALL);
            if (level.getBlockEntity(pos) instanceof BeddingBlockEntity bedding) {
                bedding.setOriginal(state);
            }
            level.playSound(null, pos, state.getSoundType().getPlaceSound(), SoundSource.BLOCKS, 1.0F, 1.0F);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
