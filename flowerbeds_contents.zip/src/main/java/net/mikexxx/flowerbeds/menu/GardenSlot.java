package net.mikexxx.flowerbeds.menu;

import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.minecraft.world.Container;
import net.minecraft.world.inventory.Slot;
import net.minecraft.world.item.ItemStack;

/** A plant or groundcover slot. Inactive slots are hidden and refuse items. */
public class GardenSlot extends Slot {

    private final boolean active;

    public GardenSlot(Container container, int index, int x, int y, boolean active) {
        super(container, index, x, y);
        this.active = active;
    }

    @Override
    public boolean isActive() {
        return active;
    }

    @Override
    public boolean mayPlace(ItemStack stack) {
        return active && GardenLayout.isBlockItem(stack);
    }

    /** Without a stack in mind a slot holds one item, so no code path can overfill it. */
    @Override
    public int getMaxStackSize() {
        return 1;
    }

    /** Stackable blocks (petals, candles, ...) fit as many as their block can show. */
    @Override
    public int getMaxStackSize(ItemStack stack) {
        return PlantStates.maxAmount(stack);
    }
}
