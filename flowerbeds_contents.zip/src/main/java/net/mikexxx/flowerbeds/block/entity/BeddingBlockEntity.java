package net.mikexxx.flowerbeds.block.entity;

import net.mikexxx.flowerbeds.registry.ModBlockEntities;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.NbtUtils;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.registries.ForgeRegistries;

/** A bedding block remembers the exact block state it was made from, which it looks like and gives back. */
public class BeddingBlockEntity extends PlantBedBlockEntity {

    private BlockState original = Blocks.DIRT.defaultBlockState();

    public BeddingBlockEntity(BlockPos pos, BlockState state) {
        super(ModBlockEntities.BEDDING.get(), pos, state);
    }

    @Override
    public float bedHeight() {
        return 1.0F;
    }

    public BlockState getOriginalState() {
        return original;
    }

    public Block getOriginal() {
        return original.getBlock();
    }

    public void setOriginal(BlockState state) {
        this.original = state;
        onSlotsChanged();
    }

    @Override
    public BlockState baseState() {
        return original;
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.put("OriginalState", NbtUtils.writeBlockState(original));
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        original = Blocks.DIRT.defaultBlockState();
        if (tag.contains("OriginalState")) {
            original = NbtUtils.readBlockState(BuiltInRegistries.BLOCK, tag.getCompound("OriginalState"));
        } else if (tag.contains("Original")) {
            ResourceLocation key = ResourceLocation.tryParse(tag.getString("Original"));
            if (key != null && ForgeRegistries.BLOCKS.containsKey(key)) {
                Block block = ForgeRegistries.BLOCKS.getValue(key);
                if (block != null) {
                    original = block.defaultBlockState();
                }
            }
        }
    }
}
