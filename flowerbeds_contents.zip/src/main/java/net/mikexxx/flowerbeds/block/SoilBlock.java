package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.SoilBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;

/** Darker, richer soil. A full block that can be planted with the trowel. */
public class SoilBlock extends PlantBedBlock {

    public SoilBlock(BlockBehaviour.Properties properties) {
        super(properties.lightLevel(state -> state.getValue(LIGHT)));
        registerDefaultState(this.stateDefinition.any().setValue(LIGHT, 0));
    }

    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new SoilBlockEntity(pos, state);
    }
}
