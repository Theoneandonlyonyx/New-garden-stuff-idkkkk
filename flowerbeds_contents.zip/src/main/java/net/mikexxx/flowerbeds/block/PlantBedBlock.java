package net.mikexxx.flowerbeds.block;

import net.mikexxx.flowerbeds.block.entity.PlantBedBlockEntity;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.garden.PlantStates;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.mikexxx.flowerbeds.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.SimpleMenuProvider;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.EntityBlock;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.NetworkHooks;

/**
 * Shared behaviour of Soil Blocks and Large Pots: the trowel opens Arrange Plants, bone meal moves
 * the plants one growth stage, and neighbouring beds are told when a bed appears or disappears.
 */
public abstract class PlantBedBlock extends Block implements EntityBlock {

    /** Light level the bed gives off, from the lanterns and candles stored in it. */
    public static final IntegerProperty LIGHT = IntegerProperty.create("light", 0, 15);

    public PlantBedBlock(BlockBehaviour.Properties properties) {
        super(properties);
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(LIGHT);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player,
                                 InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);

        if (held.is(ModItems.TROWEL.get())) {
            // Sneaking with the trowel on bedding lets the item turn it back into the original block.
            if (player.isShiftKeyDown() && state.getBlock() instanceof BeddingBlock) {
                return InteractionResult.PASS;
            }
            if (!level.isClientSide
                    && level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed
                    && player instanceof ServerPlayer serverPlayer) {
                if (canOpenMenu(state, level, pos)) {
                    openPlantMenu(serverPlayer, bed);
                } else {
                    player.displayClientMessage(Component.translatable(
                            "message.mikexxx_flowerbeds.needs_substrate"), true);
                }
            }
            return InteractionResult.SUCCESS;
        }

        if (held.is(Items.BONE_MEAL)) {
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed && bed.canGrowAny()) {
                if (!level.isClientSide) {
                    bed.growPlants();
                    level.levelEvent(2005, pos, 0);
                    if (!player.getAbilities().instabuild) {
                        held.shrink(1);
                    }
                }
                return InteractionResult.SUCCESS;
            }
            return InteractionResult.PASS;
        }

        if (allowsLoosePlanting()) {
            InteractionResult planted = loosePlant(level, pos, player, hand, held, hit);
            if (planted != InteractionResult.PASS) {
                return planted;
            }
        }

        return extraUse(state, level, pos, player, hand, held);
    }

    /** Soil and bedding take a plant from the hand. The spot is only approximate; the trowel is exact. */
    protected boolean allowsLoosePlanting() {
        return this instanceof SoilBlock || this instanceof BeddingBlock;
    }

    /**
     * Puts one plant onto the nearest of the five core places, snapped to the half of the block that was
     * clicked. Border places stay for the trowel. Groundcover goes to the groundcover place.
     */
    private InteractionResult loosePlant(Level level, BlockPos pos, Player player, InteractionHand hand,
                                         ItemStack held, BlockHitResult hit) {
        if (!(held.getItem() instanceof BlockItem) || !(level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed)) {
            return InteractionResult.PASS;
        }
        if (GardenLayout.isSubstrate(held, level, pos) && !PlantStates.isGroundcover(held)) {
            return InteractionResult.PASS;
        }
        int slot;
        boolean stacking;
        if (PlantStates.isGroundcover(held)) {
            slot = GardenLayout.GROUNDCOVER_SLOT;
            ItemStack present = bed.getSlot(slot);
            int max = PlantStates.maxAmount(held);
            if (present.isEmpty()) {
                stacking = false;
            } else if (ItemStack.isSameItemSameTags(present, held) && present.getCount() < max) {
                stacking = true;
            } else {
                return InteractionResult.PASS;
            }
        } else {
            int found = nearestCoreSlot(level, pos, bed, held, hit);
            if (found < 0) {
                return InteractionResult.PASS;
            }
            slot = found;
            stacking = !bed.getSlot(slot).isEmpty();
        }
        if (level.isClientSide) {
            return InteractionResult.SUCCESS;
        }
        if (stacking) {
            ItemStack present = bed.getSlot(slot);
            ItemStack grown = present.copy();
            grown.grow(1);
            bed.setSlot(slot, grown, bed.getAge(slot), bed.getRotation(slot));
        } else {
            bed.setSlot(slot, held.copyWithCount(1), 0, player.getDirection().get2DDataValue());
        }
        level.playSound(null, pos, SoundEvents.GRASS_PLACE, SoundSource.BLOCKS, 0.8F, 1.0F);
        if (!player.getAbilities().instabuild) {
            held.shrink(1);
        }
        return InteractionResult.SUCCESS;
    }

    /** Closest core slot to the clicked half of the block. Matching stacks are preferred, then empty slots. */
    private static int nearestCoreSlot(Level level, BlockPos pos, PlantBedBlockEntity bed, ItemStack held,
                                       BlockHitResult hit) {
        Vec3 loc = hit.getLocation();
        double qx = (loc.x - pos.getX()) < 0.5 ? 0.25 : 0.75;
        double qz = (loc.z - pos.getZ()) < 0.5 ? 0.25 : 0.75;
        int bestStack = -1;
        int bestEmpty = -1;
        double bestStackD = Double.MAX_VALUE;
        double bestEmptyD = Double.MAX_VALUE;
        int max = PlantStates.maxAmount(held);
        for (int i = 0; i < GardenLayout.CORE_SLOTS; i++) {
            GardenLayout.Owner owner = GardenLayout.resolve(level, pos, i);
            if (!owner.active() || !owner.pos().equals(pos)) {
                continue;
            }
            double dx = GardenLayout.localX(i) - qx;
            double dz = GardenLayout.localZ(i) - qz;
            double d = dx * dx + dz * dz;
            ItemStack present = bed.getSlot(i);
            if (present.isEmpty()) {
                if (d < bestEmptyD) {
                    bestEmptyD = d;
                    bestEmpty = i;
                }
            } else if (ItemStack.isSameItemSameTags(present, held) && present.getCount() < max && d < bestStackD) {
                bestStackD = d;
                bestStack = i;
            }
        }
        if (bestStack >= 0 && (bestEmpty < 0 || bestStackD <= bestEmptyD)) {
            return bestStack;
        }
        return bestEmpty;
    }

    /** Whether the trowel may open Arrange Plants here. A pot first needs a substrate or a liquid. */
    protected boolean canOpenMenu(BlockState state, Level level, BlockPos pos) {
        return true;
    }

    /** Hook for block-specific interaction (the Large Pot uses it for liquids and dye). */
    protected InteractionResult extraUse(BlockState state, Level level, BlockPos pos, Player player,
                                         InteractionHand hand, ItemStack held) {
        return InteractionResult.PASS;
    }

    private static void openPlantMenu(ServerPlayer player, PlantBedBlockEntity bed) {
        BlockPos pos = bed.getBlockPos();
        int mask = GardenLayout.activeMask(bed.getLevel(), pos);
        int facing = player.getDirection().get2DDataValue();
        boolean pot = GardenLayout.isPot(bed.getBlockState());
        NetworkHooks.openScreen(player,
                new SimpleMenuProvider((id, inv, p) -> new PlantBedMenu(id, inv, bed, facing),
                        Component.translatable("container.mikexxx_flowerbeds.plant_bed")),
                buf -> {
                    buf.writeBlockPos(pos);
                    buf.writeBoolean(pot);
                    buf.writeInt(mask);
                    buf.writeInt(facing);
                });
    }

    @Override
    public void onPlace(BlockState state, Level level, BlockPos pos, BlockState oldState, boolean isMoving) {
        super.onPlace(state, level, pos, oldState, isMoving);
        if (!level.isClientSide && !state.is(oldState.getBlock())) {
            reconcileAround(level, pos);
        }
    }

    @Override
    public void onRemove(BlockState state, Level level, BlockPos pos, BlockState newState, boolean isMoving) {
        if (!state.is(newState.getBlock())) {
            if (level.getBlockEntity(pos) instanceof PlantBedBlockEntity bed) {
                bed.dropContents();
            }
            level.removeBlockEntity(pos);
            if (!level.isClientSide) {
                reconcileAround(level, pos);
            }
        }
        super.onRemove(state, level, pos, newState, isMoving);
    }

    private static void reconcileAround(Level level, BlockPos pos) {
        for (Direction side : GardenLayout.SIDES) {
            if (level.getBlockEntity(pos.relative(side)) instanceof PlantBedBlockEntity bed) {
                bed.reconcile();
            }
        }
    }
}
