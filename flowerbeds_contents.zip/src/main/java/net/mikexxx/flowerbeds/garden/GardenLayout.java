package net.mikexxx.flowerbeds.garden;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.block.BeddingBlock;
import net.mikexxx.flowerbeds.block.LargePotBlock;
import net.mikexxx.flowerbeds.block.PlantBedBlock;
import net.mikexxx.flowerbeds.block.SoilBlock;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.IPlantable;

/**
 * Slot layout shared by Soil Blocks and Large Pots.
 *
 * Each bed has a 5x5 grid of quarter-block positions (0..4 in each direction).
 *   - 5 core slots: the centre and the four inner diagonals. They are always available.
 *   - 12 border slots: three per side. Each side's three slots sit on that side only, at the
 *     quarter points between its corners. A side's slots exist when a plantable block is on that
 *     side, and they are shared with that neighbour. Nothing is shared with a diagonal block.
 *   - 1 groundcover slot, drawn flat over the bed.
 */
public final class GardenLayout {
    private GardenLayout() {}

    public static final int CORE_SLOTS = 5;
    public static final int SIDE_SLOTS = 3;
    public static final int PLANT_SLOTS = CORE_SLOTS + 4 * SIDE_SLOTS;
    /** A large pot always has this many of its own plant places, in an even 3x3. They are never shared. */
    public static final int POT_PLANT_SLOTS = 9;
    public static final int GROUNDCOVER_SLOT = PLANT_SLOTS;
    public static final int SLOT_COUNT = GROUNDCOVER_SLOT + 1;

    /** Soil inside a pot: from the floor up to one pixel under the rim. */
    public static final float POT_FILL_BOTTOM = 2.0F / 16.0F;
    public static final float POT_FILL_TOP = 15.0F / 16.0F;
    /** Water sits a little under the rim so the lip still reads, and plants stand just over it. */
    public static final float POT_WATER_TOP = 14.75F / 16.0F;

    /** Grid position (0..4) of each plant slot, in slot order. Border slots: N, E, S, W, three each. */
    public static final int[] GRID_X = {2, 1, 3, 1, 3,   1, 2, 3,   4, 4, 4,   1, 2, 3,   0, 0, 0};
    public static final int[] GRID_Z = {2, 1, 1, 3, 3,   0, 0, 0,   1, 2, 3,   4, 4, 4,   1, 2, 3};

    /** Sides in slot order. The side index of a border slot is (slot - CORE_SLOTS) / SIDE_SLOTS. */
    public static final Direction[] SIDES = {Direction.NORTH, Direction.EAST, Direction.SOUTH, Direction.WEST};

    /** Scaled fruit (pumpkins, melons, jack-o'-lanterns and modded fruit) is drawn at this size. */
    public static final float SCALED_FRUIT_SCALE = 0.5F;
    /** Light given by candles and lanterns that do not emit light themselves. */
    public static final int CANDLE_LIGHT = 12;
    public static final int LANTERN_LIGHT = 15;

    public static final TagKey<Block> PLANTABLE =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "plantable"));
    /** Blocks that can fill a pot as a growing medium: soil, dirt, sand and the like. */
    public static final TagKey<Block> SUBSTRATES =
            TagKey.create(Registries.BLOCK, new ResourceLocation(PmpMikexxx.MODID, "substrates"));
    public static final TagKey<Item> LANTERNS =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "lanterns"));
    public static final TagKey<Item> CANDLES =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "candles"));
    public static final TagKey<Item> SCALED_FRUIT =
            TagKey.create(Registries.ITEM, new ResourceLocation(PmpMikexxx.MODID, "scaled_fruit"));

    /** Result of resolving a slot: whether it exists, and which bed stores its item. */
    public record Owner(boolean active, BlockPos pos, int slot) {}

    public static int sideSlot(int side, int index) {
        return CORE_SLOTS + side * SIDE_SLOTS + index;
    }

    /**
     * Column (0..4) of a plant slot in the GUI. The GUI is turned so that the way the player faces is "up":
     * a player looking north sees north at the top, a player looking east sees east at the top, and so on.
     * {@code facing} is {@link Direction#get2DDataValue()} of the player (south 0, west 1, north 2, east 3).
     */
    public static int guiX(int slot, int facing) {
        int u = GRID_X[slot] - 2;
        int v = GRID_Z[slot] - 2;
        return 2 + switch (facing & 3) {
            case 3 -> v;      // east is up
            case 0 -> -u;     // south is up
            case 1 -> -v;     // west is up
            default -> u;     // north is up
        };
    }

    /** Row (0..4) of a plant slot in the GUI, turned the same way as {@link #guiX}. */
    public static int guiZ(int slot, int facing) {
        int u = GRID_X[slot] - 2;
        int v = GRID_Z[slot] - 2;
        return 2 + switch (facing & 3) {
            case 3 -> -u;
            case 0 -> -v;
            case 1 -> u;
            default -> v;
        };
    }

    public static float localX(int slot) {
        return GRID_X[slot] / 4.0F;
    }

    public static float localZ(int slot) {
        return GRID_Z[slot] / 4.0F;
    }

    /** Even 3x3 inside a pot, kept off the two-pixel walls. */
    public static float potLocalX(int slot) {
        return 0.25F + (slot % 3) * 0.25F;
    }

    public static float potLocalZ(int slot) {
        return 0.25F + (slot / 3) * 0.25F;
    }

    public static boolean isPot(BlockState state) {
        return state.getBlock() instanceof LargePotBlock;
    }

    public static boolean isPlantableState(BlockState state) {
        return state.getBlock() instanceof PlantBedBlock || state.is(PLANTABLE);
    }

    /** Whether the item is a block that something grows on (see {@link #isSubstrateState}). */
    public static boolean isSubstrate(ItemStack stack, BlockGetter level, BlockPos pos) {
        return stack.getItem() instanceof BlockItem blockItem
                && isSubstrateState(blockItem.getBlock().defaultBlockState(), level, pos);
    }

    /**
     * Whether a block is something that grows plants: anything in the substrates tag, or any full block
     * that vanilla/Forge plant rules say can hold a sapling, a cactus or sugar cane. Blocks with a block
     * entity (chests, furnaces, our own beds) are never substrates.
     */
    public static boolean isSubstrateState(BlockState state, BlockGetter level, BlockPos pos) {
        Block block = state.getBlock();
        // The substrates tag wins, so the mod's own soil block can fill a pot. Other plant beds
        // (pots, bedding, window boxes) stay excluded even if a pack adds them to the tag.
        if (state.is(SUBSTRATES)) {
            return !(block instanceof PlantBedBlock) || block instanceof SoilBlock;
        }
        if (block instanceof PlantBedBlock || state.hasBlockEntity()) {
            return false;
        }
        try {
            if (!state.isCollisionShapeFullBlock(level, pos)) {
                return false;
            }
            for (Block plant : new Block[] {Blocks.OAK_SAPLING, Blocks.CACTUS, Blocks.SUGAR_CANE}) {
                if (plant instanceof IPlantable plantable
                        && state.canSustainPlant(level, pos, Direction.UP, plantable)) {
                    return true;
                }
            }
        } catch (RuntimeException ignored) {
            // A modded block that cannot answer without a real world position is not a substrate.
        }
        return false;
    }

    /** Plants and groundcover: any block item. Non-block items have no world model to draw. */
    public static boolean isBlockItem(ItemStack stack) {
        return stack.getItem() instanceof BlockItem;
    }

    public static boolean isScaled(ItemStack stack) {
        return stack.getItem() instanceof BlockItem && stack.is(SCALED_FRUIT);
    }

    /** Light the item gives while it sits in a bed (0 if none). */
    public static int lightOf(ItemStack stack) {
        if (!(stack.getItem() instanceof BlockItem blockItem)) {
            return 0;
        }
        int emitted = blockItem.getBlock().defaultBlockState().getLightEmission();
        if (stack.is(CANDLES)) {
            return Math.max(emitted, CANDLE_LIGHT);
        }
        if (stack.is(LANTERNS)) {
            return Math.max(emitted, LANTERN_LIGHT);
        }
        return emitted;
    }

    /**
     * Works out whether a slot of the bed at {@code bed} exists, and which bed stores it.
     * Core slots always belong to the bed. A border slot exists when the neighbour on its side is
     * plantable, and it is stored by whichever of the two beds has the smaller position.
     */
    public static Owner resolve(Level level, BlockPos bed, int slot) {
        if (isPot(level.getBlockState(bed))) {
            if (slot < POT_PLANT_SLOTS || slot == GROUNDCOVER_SLOT) {
                return new Owner(true, bed, slot);
            }
            return new Owner(false, bed, slot);
        }
        if (slot < CORE_SLOTS) {
            return new Owner(true, bed, slot);
        }
        int rel = slot - CORE_SLOTS;
        int side = rel / SIDE_SLOTS;
        int index = rel % SIDE_SLOTS;

        BlockPos neighbor = bed.relative(SIDES[side]);
        if (!sharesSide(level, bed, neighbor)) {
            return new Owner(false, bed, slot);
        }
        if (level.getBlockState(neighbor).getBlock() instanceof PlantBedBlock && compare(neighbor, bed) < 0) {
            // The neighbour's slot on the opposite side covers the same boundary.
            return new Owner(true, neighbor, sideSlot((side + 2) % 4, index));
        }
        return new Owner(true, bed, slot);
    }

    /** Bit i is set when plant slot i of the bed exists. */
    public static int activeMask(Level level, BlockPos bed) {
        if (isPot(level.getBlockState(bed))) {
            return (1 << POT_PLANT_SLOTS) - 1;
        }
        int mask = 0;
        for (int i = 0; i < PLANT_SLOTS; i++) {
            if (resolve(level, bed, i).active()) {
                mask |= 1 << i;
            }
        }
        return mask;
    }

    /** Whether a bed of this kind opens its side toward the other block. Soil and bedding open to any plantable block; a pot only to pots of the same kind. */
    public static boolean bedOpensTo(BlockState bed, BlockState other) {
        if (bed.getBlock() instanceof SoilBlock || bed.getBlock() instanceof BeddingBlock) {
            return isPlantableState(other);
        }
        if (bed.getBlock() instanceof LargePotBlock) {
            return other.getBlock() == bed.getBlock();
        }
        return false;
    }

    /**
     * A side has shared border slots only when the two blocks open toward each other. Two beds must both
     * open toward each other; a plain plantable block (dirt, grass, ...) only needs to be opened to by the bed.
     */
    public static boolean sharesSide(Level level, BlockPos bed, BlockPos neighbor) {
        BlockState self = level.getBlockState(bed);
        BlockState other = level.getBlockState(neighbor);
        if (other.getBlock() instanceof PlantBedBlock) {
            return bedOpensTo(self, other) && bedOpensTo(other, self);
        }
        return bedOpensTo(self, other);
    }

    private static int compare(BlockPos a, BlockPos b) {
        int c = Integer.compare(a.getX(), b.getX());
        return c != 0 ? c : Integer.compare(a.getZ(), b.getZ());
    }
}
