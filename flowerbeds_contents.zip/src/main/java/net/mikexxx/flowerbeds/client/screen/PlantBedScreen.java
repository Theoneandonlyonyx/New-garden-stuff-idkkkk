package net.mikexxx.flowerbeds.client.screen;

import net.mikexxx.flowerbeds.PmpMikexxx;
import net.mikexxx.flowerbeds.garden.GardenLayout;
import net.mikexxx.flowerbeds.menu.PlantBedMenu;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.inventory.AbstractContainerScreen;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.inventory.Slot;

public class PlantBedScreen extends AbstractContainerScreen<PlantBedMenu> {

    private static final ResourceLocation TEXTURE =
            new ResourceLocation(PmpMikexxx.MODID, "textures/gui/plant_bed.png");

    /** Where the 18-pixel slot tile sits in the GUI texture. */
    private static final int TILE_U = 200;
    private static final int TILE_V = 0;
    private static final int TILE_SIZE = 18;

    public PlantBedScreen(PlantBedMenu menu, Inventory inventory, Component title) {
        super(menu, inventory, title);
        this.imageWidth = 176;
        this.imageHeight = 204;
        this.inventoryLabelY = this.imageHeight - 94;
    }

    @Override
    protected void renderBg(GuiGraphics graphics, float partialTick, int mouseX, int mouseY) {
        graphics.blit(TEXTURE, leftPos, topPos, 0, 0, imageWidth, imageHeight, 256, 256);
        // Only the slots that exist for this bed get a tile, so a border that has no neighbour stays blank.
        for (int i = 0; i < GardenLayout.PLANT_SLOTS; i++) {
            Slot slot = menu.getSlot(i);
            if (slot.isActive()) {
                graphics.blit(TEXTURE, leftPos + slot.x - 1, topPos + slot.y - 1,
                        TILE_U, TILE_V, TILE_SIZE, TILE_SIZE, 256, 256);
            }
        }
    }
}
